Tiny-Alert
==========

A JavaScript Lib Based On Zepto

[Read More...](http://shootyou.github.io/Tiny-Alert/)